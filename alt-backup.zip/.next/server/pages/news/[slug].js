"use strict";
(() => {
var exports = {};
exports.id = 376;
exports.ids = [376];
exports.modules = {

/***/ 7234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Single),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/base/Header.js
var Header = __webpack_require__(8521);
// EXTERNAL MODULE: ./components/homepage/Slide.js + 1 modules
var Slide = __webpack_require__(8195);
// EXTERNAL MODULE: ./components/base/Divider.js
var Divider = __webpack_require__(8934);
// EXTERNAL MODULE: ./components/base/Footer.js
var Footer = __webpack_require__(3103);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./components/base/CategoriesList.js


function Card(props) {
    const { categories =[]  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "grid gap-4",
        children: categories.map((category, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                onClick: ()=>router_default().push("/category/" + category.slug)
                ,
                className: "cursor-pointer border-l-4 border-transparent hover:border-secundary transition-colors duration-300 p-4 px-6 ",
                children: category.name
            }, "category" + i)
        )
    });
};

// EXTERNAL MODULE: ./components/base/Seo.js
var Seo = __webpack_require__(6745);
// EXTERNAL MODULE: ./utils/wordpress.js
var wordpress = __webpack_require__(1386);
;// CONCATENATED MODULE: ./pages/news/[slug].js








function Single(props) {
    const BASE_URL = "altera.consulting";
    const { post , categories , slug  } = props;
    const { title , content , _embedded , featured_image_src , authorName , date , excerpt  } = post;
    const avatar = _embedded.author[0].avatar_urls["48"];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Seo/* default */.Z, {
                canonical: BASE_URL + "/news/" + slug,
                ogImage: featured_image_src,
                title: title.rendered,
                description: excerpt.rendered
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                activeBg: true,
                position: "fixed"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-[150px] mb-[100px] container mx-auto grid grid-cols-1 gap-8 md:grid-cols-3",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "md:col-span-2 relative grid gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-3xl",
                                children: title.rendered
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("picture", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    alt: "image",
                                    className: "rounded-xl",
                                    src: featured_image_src
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "grid gap-4",
                                dangerouslySetInnerHTML: {
                                    __html: content.rendered
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Divider/* default */.Z, {})
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " flex items-center gap-2 justify-between",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("picture", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    alt: "avatar",
                                                    src: avatar,
                                                    className: "w-[50px] h-[50px] object-cover rounded-full inline-flex mr-2"
                                                })
                                            }),
                                            "di ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                children: authorName
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex gap-2 items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                className: "h-5 w-5 stroke-[#0cf] stroke-[2px] mr-[5px]",
                                                fill: "none",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                                                })
                                            }),
                                            new Date(date).toLocaleDateString("it-IT")
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "text-xl text-left pl-7 pb-4 border-b-2 border-secundary mb-4",
                                children: "CATEGORIE"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Card, {
                                categories: categories
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
};
async function getServerSideProps(context) {
    const { slug  } = context.params;
    const post = await (0,wordpress/* getPost */.xl)(slug);
    const categories = await (0,wordpress/* getCategories */.CP)();
    return {
        props: {
            post,
            categories,
            slug
        }
    };
}


/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,981,386,195,745], () => (__webpack_exec__(7234)));
module.exports = __webpack_exports__;

})();