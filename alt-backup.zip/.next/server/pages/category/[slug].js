"use strict";
(() => {
var exports = {};
exports.id = 24;
exports.ids = [24];
exports.modules = {

/***/ 7905:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Category),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/base/Header.js
var Header = __webpack_require__(8521);
// EXTERNAL MODULE: ./components/base/Footer.js
var Footer = __webpack_require__(3103);
;// CONCATENATED MODULE: ./components/base/Layouts.js

// components/layout.js


function Layout({ props , children  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                position: "fixed"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "min-h-screen pt-[100px]",
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
};

// EXTERNAL MODULE: ./components/base/Icon.js
var Icon = __webpack_require__(8089);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./components/category/postsGrid.js





function postGrid(props) {
    const { posts  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "grid md:grid-cols-2 gap-6",
        children: [
            " ",
            posts.map((post, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid gap-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("picture", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                className: "cursor-pointer rounded-[20px] object-cover max-h-[350px] w-full",
                                onClick: ()=>router_default().push("/news/" + post.slug)
                                ,
                                src: post.featured_image_src,
                                title: "img"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center publication-date text-primary",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Icon/* default */.Z, {
                                    name: "calendar",
                                    css: "h-5 w-5 stroke-primary stroke-[2px] mr-[5px]"
                                }),
                                " ",
                                new Date(post.date).toLocaleDateString("it-IT")
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                onClick: ()=>router_default().push("/news/" + post.slug)
                                ,
                                className: "cursor-pointer text-primary troncato font-extrabold",
                                dangerouslySetInnerHTML: {
                                    __html: post.title.rendered
                                }
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-primary troncato font-thin",
                                dangerouslySetInnerHTML: {
                                    __html: post.excerpt.rendered
                                }
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("picture", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: "w-10 h-10 rounded-full",
                                        src: post._embedded.author[0].avatar_urls["24"]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "ml-4 text-primary font-semibold",
                                    children: [
                                        "by  ",
                                        post.authorName
                                    ]
                                })
                            ]
                        })
                    ]
                }, "posts" + i)
            )
        ]
    });
};

;// CONCATENATED MODULE: ./components/category/search.js

function search(props) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                className: " focus:outline-none border-2 border-primary rounded-xl w-full p-3",
                type: "search",
                placeholder: "Enter your keywords"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "hover:bg-secundary transition-colors absolute right-3 top-3 p-3 text-white bg-primary rounded-xl",
                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    className: "w-6 h-6",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "2",
                        d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    })
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/category/Category.js


function Category_category(props) {
    const { category: category1 = {}  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        onClick: ()=>router_default().push("/category/" + category1.slug)
        ,
        className: "cursor-pointer hover:text-primary flex items-center gap-4 py-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-sm block",
                children: category1.name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex-1 h-[3px] bg-gray-200"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: category1.count
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/category/categories.js


function categories_categories(props) {
    const { categories: categories1 = []  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-2xl border-b-2 border-primary pb-2",
                children: " CATEGORIES "
            }),
            categories1.filter((c)=>c.count > 0
            ).map((category, i)=>/*#__PURE__*/ jsx_runtime_.jsx(Category_category, {
                    category: category
                }, "category" + i)
            )
        ]
    });
};

;// CONCATENATED MODULE: ./components/category/recent.js



function recent(props) {
    const { news =[]  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                className: "text-2xl border-b-2 border-primary pb-2",
                children: [
                    " Recent ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: " font-[200]",
                        children: " Updates "
                    }),
                    " "
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "grid gap-4 mt-4",
                children: news.map((post, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                className: "cursor-pointer rounded-[20px] object-cover w-[100px] h-[100px]",
                                onClick: ()=>router_default().push("/news/" + post.slug)
                                ,
                                src: post.featured_image_src,
                                title: "img"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid gap-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center publication-date",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Icon/* default */.Z, {
                                                name: "calendar",
                                                css: "h-5 w-5 stroke-[#0cf] stroke-[2px] mr-[5px]"
                                            }),
                                            " ",
                                            new Date(post.date).toLocaleDateString("it-IT")
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "troncato",
                                            dangerouslySetInnerHTML: {
                                                __html: post.title.rendered
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: " text-primary font-semibold",
                                                children: [
                                                    "by  ",
                                                    post.authorName
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "flex gap-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                        className: "w-6 h-6 text-primary",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: "2",
                                                            d: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                                                        })
                                                    }),
                                                    "123"
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }, "recent" + i)
                )
            })
        ]
    });
};

// EXTERNAL MODULE: ./utils/wordpress.js
var wordpress = __webpack_require__(1386);
;// CONCATENATED MODULE: ./pages/category/[slug].js







function Category(props) {
    const { posts , categories , news  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container mx-auto md:grid grid-cols-3 gap-6 py-[100px]",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "md:col-span-2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(postGrid, {
                        posts: posts
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "md:col-span-1 flex flex-col gap-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(search, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(categories_categories, {
                            categories: categories
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(recent, {
                            news: news
                        })
                    ]
                })
            ]
        })
    });
};
async function getServerSideProps(context) {
    const { slug  } = context.params;
    const currentCategory = await (0,wordpress/* getCategory */.n3)({
        slug
    });
    const [posts, news] = await Promise.all([
        await (0,wordpress/* getPosts */.Jq)({
            categories: currentCategory.id
        }),
        await (0,wordpress/* getPosts */.Jq)()
    ]);
    const categories = await (0,wordpress/* getCategories */.CP)();
    return {
        props: {
            posts,
            categories,
            news
        }
    };
}


/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,981,386], () => (__webpack_exec__(7905)));
module.exports = __webpack_exports__;

})();