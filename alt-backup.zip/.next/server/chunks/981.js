"use strict";
exports.id = 981;
exports.ids = [981];
exports.modules = {

/***/ 8934:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Divider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Divider(props) {
    if (props.type == "footer") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "divider footer relative pb-10"
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "divider relative pb-10"
        });
    }
};


/***/ }),

/***/ 3103:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Divider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8934);



function Footer() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-primary pb-5",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container mx-auto grid grid-cols-1 md:grid-cols-4 pt-[100px] md:pt-[100px]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-span-1 flex flex-row justify-center items-center pb-10 md:pb-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("picture", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/images/logo-white.png",
                                    width: "200px"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-span-1 flex flex-row justify-center pb-10 md:pb-0",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col items-center md:items-start",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    className: "text-white mb-5",
                                    children: "Social Network"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-row",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            legacyBehavior: true,
                                            href: "https://www.facebook.com/altera.consulting",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "pr-3 pl-3 md:pl-0 md:pr-5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("picture", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "/images/facebook.png"
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            legacyBehavior: true,
                                            href: "https://www.instagram.com/altera_consulting/",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "pr-3 pl-3 md:pl-0 md:pr-5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("picture", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "/images/instagram.png"
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            legacyBehavior: true,
                                            href: "https://www.linkedin.com/company/altera-consulting-company/",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "pr-3 pl-3 md:pl-0 md:pr-5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("picture", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "/images/linkedin.png"
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-span-1 flex flex-row justify-center pb-10 md:pb-0",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col items-center md:items-start",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    className: "text-white mb-5",
                                    children: "Link utili"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            legacyBehavior: true,
                                            href: "/privacy-policy",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "text-white pr-3 pl-3 md:pl-0 md:pr-5",
                                                children: "Privacy Policy"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            legacyBehavior: true,
                                            href: "/cookie-policy",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "text-white pr-3 pl-3 md:pl-0 md:pr-5",
                                                children: "Cookie Policy"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-span-1 flex flex-row justify-center pb-10 md:pb-0",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col items-center md:items-start",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    className: "text-white mb-5",
                                    children: "Info e Contatti"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "text-white font-[400]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                            children: "Email:"
                                        }),
                                        " info@altera.consulting"
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "pt-14 px-[15px]",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Divider__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    type: "footer"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container mx-auto text-center text-white text-[15px]",
                children: "Altera \xa92022 - P.IVA: 03195120591 - All rights reserved"
            })
        ]
    });
};


/***/ }),

/***/ 8521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8089);




function NavLink({ to , children , className  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        href: to,
        className: `${className ? className : "px-[30px]"}`,
        children: children
    });
}
function MobileNav({ open , setOpen  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `md:hidden absolute top-0 left-0 h-screen w-screen bg-white transform ${open ? "-translate-x-0" : "-translate-x-full"} transition-transform duration-300 ease-in-out filter drop-shadow-md `,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center justify-start px-5 filter drop-shadow-md bg-white h-20",
                children: [
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        legacyBehavior: true,
                        className: "text-xl",
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: `text-2xl md:text-[35px] font-bold `,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("picture", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/images/logo.png",
                                    width: "150px"
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex text-[#001d4f] flex-col ml-4 pt-5 text-[25px]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        legacyBehavior: true,
                        href: "#about",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            onClick: ()=>setTimeout(()=>{
                                    setOpen(!open);
                                }, 100)
                            ,
                            children: "Chi siamo"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        legacyBehavior: true,
                        href: "#services",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            onClick: ()=>setTimeout(()=>{
                                    setOpen(!open);
                                }, 100)
                            ,
                            children: "Servizi"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        legacyBehavior: true,
                        href: "#contact",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            onClick: ()=>setTimeout(()=>{
                                    setOpen(!open);
                                }, 100)
                            ,
                            children: "Contact"
                        })
                    })
                ]
            })
        ]
    });
}
function Header(props) {
    const position = props.position == "fixed" ? true : false;
    const activeBg = props.activeBg;
    const { 0: scrollY , 1: setScrollY  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleScroll = ()=>{
            setScrollY(window.scrollY);
        };
        handleScroll();
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: `flex filter ${position ? "position-fixed" : ""} drop-shadow-md ${scrollY || activeBg > 0 ? "bg-primary" : "bg-none"} px-4 py-4 h-20 items-center `,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container mx-auto flex",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MobileNav, {
                    open: open,
                    setOpen: setOpen
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-3/12 flex items-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        legacyBehavior: true,
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: `text-2xl md:text-[35px] font-bold `,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("picture", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: scrollY > 0 ? "/images/logo-white.png" : "/images/logo-white.png",
                                    width: "150px"
                                })
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-9/12 flex justify-end items-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "z-50 flex relative w-7 h-5 flex-col justify-between items-center md:hidden",
                            onClick: ()=>{
                                setOpen(!open);
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: `h-[2px] w-full bg-white rounded-lg transform transition duration-300 ease-in-out ${open ? "bg-[#001d4f] rotate-45 translate-y-2.5" : ""}`
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: `h-[2px] w-full  bg-white rounded-lg transition-all duration-300 ease-in-out ${open ? "bg-[#001d4f] w-0" : "w-full"}`
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: `h-[2px] w-full  bg-white rounded-lg transform transition duration-300 ease-in-out ${open ? "bg-[#001d4f] -rotate-45 -translate-y-2.5" : ""}`
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `hidden md:flex  d-flex items-center text-[15px]  `,
                            children: [
                                props.Home ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavLink, {
                                    to: "#about",
                                    children: "Chi siamo"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavLink, {
                                    to: "/#about",
                                    children: "Chi siamo"
                                }),
                                props.Home ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavLink, {
                                    to: "#services",
                                    children: "Servizi"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavLink, {
                                    to: "/#services",
                                    children: "Servizi"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavLink, {
                                    to: "/category",
                                    children: "Blog"
                                }),
                                props.Home ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavLink, {
                                    to: "#contact",
                                    className: "duration-200 border border-white hover:bg-white hover:text-primary py-[15px] ml-[30px] px-[25px] rounded-[10px]",
                                    children: "Contattaci"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavLink, {
                                    to: "/#contact",
                                    children: "Contattaci"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};


/***/ }),

/***/ 8089:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Icon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Icon(props) {
    return props.name == "development" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        fill: "none",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"
        })
    }) : props.name == "events" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        fill: "none",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
        })
    }) : props.name == "light" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        fill: "none",
        viewBox: "0 0 24 24",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"
            })
        ]
    }) : props.name == "insights" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        fill: "none",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"
        })
    }) : props.name == "arrow-right" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        fill: "none",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M13 7l5 5m0 0l-5 5m5-5H6"
        })
    }) : props.name == "calendar" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        fill: "none",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
        })
    }) : props.name == "user" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        fill: "none",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
        })
    }) : props.name == "plus" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        viewBox: "0 0 60 60",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M18 54H9C8.20435 54 7.44129 53.6839 6.87868 53.1213C6.31607 52.5587 6 51.7956 6 51V42C6 41.2044 5.68393 40.4413 5.12132 39.8787C4.55871 39.3161 3.79565 39 3 39C2.20435 39 1.44129 39.3161 0.87868 39.8787C0.31607 40.4413 0 41.2044 0 42V51C0 53.3869 0.948212 55.6761 2.63604 57.364C4.32387 59.0518 6.61305 60 9 60H18C18.7956 60 19.5587 59.6839 20.1213 59.1213C20.6839 58.5587 21 57.7956 21 57C21 56.2044 20.6839 55.4413 20.1213 54.8787C19.5587 54.3161 18.7956 54 18 54V54ZM3 21C3.79565 21 4.55871 20.6839 5.12132 20.1213C5.68393 19.5587 6 18.7956 6 18V9C6 8.20435 6.31607 7.44129 6.87868 6.87868C7.44129 6.31607 8.20435 6 9 6H18C18.7956 6 19.5587 5.68393 20.1213 5.12132C20.6839 4.55871 21 3.79565 21 3C21 2.20435 20.6839 1.44129 20.1213 0.87868C19.5587 0.31607 18.7956 0 18 0H9C6.61305 0 4.32387 0.948212 2.63604 2.63604C0.948212 4.32387 0 6.61305 0 9V18C0 18.7956 0.31607 19.5587 0.87868 20.1213C1.44129 20.6839 2.20435 21 3 21ZM51 0H42C41.2044 0 40.4413 0.31607 39.8787 0.87868C39.3161 1.44129 39 2.20435 39 3C39 3.79565 39.3161 4.55871 39.8787 5.12132C40.4413 5.68393 41.2044 6 42 6H51C51.7956 6 52.5587 6.31607 53.1213 6.87868C53.6839 7.44129 54 8.20435 54 9V18C54 18.7956 54.3161 19.5587 54.8787 20.1213C55.4413 20.6839 56.2044 21 57 21C57.7956 21 58.5587 20.6839 59.1213 20.1213C59.6839 19.5587 60 18.7956 60 18V9C60 6.61305 59.0518 4.32387 57.364 2.63604C55.6761 0.948212 53.3869 0 51 0ZM42 30C42 29.2044 41.6839 28.4413 41.1213 27.8787C40.5587 27.3161 39.7956 27 39 27H33V21C33 20.2044 32.6839 19.4413 32.1213 18.8787C31.5587 18.3161 30.7956 18 30 18C29.2044 18 28.4413 18.3161 27.8787 18.8787C27.3161 19.4413 27 20.2044 27 21V27H21C20.2044 27 19.4413 27.3161 18.8787 27.8787C18.3161 28.4413 18 29.2044 18 30C18 30.7956 18.3161 31.5587 18.8787 32.1213C19.4413 32.6839 20.2044 33 21 33H27V39C27 39.7956 27.3161 40.5587 27.8787 41.1213C28.4413 41.6839 29.2044 42 30 42C30.7956 42 31.5587 41.6839 32.1213 41.1213C32.6839 40.5587 33 39.7956 33 39V33H39C39.7956 33 40.5587 32.6839 41.1213 32.1213C41.6839 31.5587 42 30.7956 42 30ZM57 39C56.2044 39 55.4413 39.3161 54.8787 39.8787C54.3161 40.4413 54 41.2044 54 42V51C54 51.7956 53.6839 52.5587 53.1213 53.1213C52.5587 53.6839 51.7956 54 51 54H42C41.2044 54 40.4413 54.3161 39.8787 54.8787C39.3161 55.4413 39 56.2044 39 57C39 57.7956 39.3161 58.5587 39.8787 59.1213C40.4413 59.6839 41.2044 60 42 60H51C53.3869 60 55.6761 59.0518 57.364 57.364C59.0518 55.6761 60 53.3869 60 51V42C60 41.2044 59.6839 40.4413 59.1213 39.8787C58.5587 39.3161 57.7956 39 57 39Z"
        })
    }) : props.name == "doc" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: props.css,
        viewBox: "0 0 60 60",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M15 24H18C18.7956 24 19.5587 23.6839 20.1213 23.1213C20.6839 22.5587 21 21.7956 21 21C21 20.2044 20.6839 19.4413 20.1213 18.8787C19.5587 18.3161 18.7956 18 18 18H15C14.2044 18 13.4413 18.3161 12.8787 18.8787C12.3161 19.4413 12 20.2044 12 21C12 21.7956 12.3161 22.5587 12.8787 23.1213C13.4413 23.6839 14.2044 24 15 24ZM27 42H15C14.2044 42 13.4413 42.3161 12.8787 42.8787C12.3161 43.4413 12 44.2043 12 45C12 45.7957 12.3161 46.5587 12.8787 47.1213C13.4413 47.6839 14.2044 48 15 48H27C27.7956 48 28.5587 47.6839 29.1213 47.1213C29.6839 46.5587 30 45.7957 30 45C30 44.2043 29.6839 43.4413 29.1213 42.8787C28.5587 42.3161 27.7956 42 27 42ZM27 30H15C14.2044 30 13.4413 30.3161 12.8787 30.8787C12.3161 31.4413 12 32.2043 12 33C12 33.7957 12.3161 34.5587 12.8787 35.1213C13.4413 35.6839 14.2044 36 15 36H27C27.7956 36 28.5587 35.6839 29.1213 35.1213C29.6839 34.5587 30 33.7957 30 33C30 32.2043 29.6839 31.4413 29.1213 30.8787C28.5587 30.3161 27.7956 30 27 30ZM47.76 22.14C47.9897 21.5937 48.0525 20.9915 47.9404 20.4096C47.8283 19.8276 47.5463 19.2919 47.13 18.87L29.13 0.87C28.882 0.636649 28.5985 0.444243 28.29 0.3C28.2005 0.28728 28.1096 0.28728 28.02 0.3L27.18 0H9C6.61305 0 4.32387 0.948212 2.63604 2.63604C0.948212 4.32387 0 6.61305 0 9V51C0 53.3869 0.948212 55.6761 2.63604 57.364C4.32387 59.0518 6.61305 60 9 60H27C27.7956 60 28.5587 59.6839 29.1213 59.1213C29.6839 58.5587 30 57.7957 30 57C30 56.2043 29.6839 55.4413 29.1213 54.8787C28.5587 54.3161 27.7956 54 27 54H9C8.20435 54 7.44129 53.6839 6.87868 53.1213C6.31607 52.5587 6 51.7957 6 51V9C6 8.20435 6.31607 7.44129 6.87868 6.87868C7.44129 6.31607 8.20435 6 9 6H24V15C24 17.3869 24.9482 19.6761 26.636 21.364C28.3239 23.0518 30.6131 24 33 24H45C45.5923 23.997 46.1704 23.8188 46.6616 23.4878C47.1527 23.1568 47.5349 22.6879 47.76 22.14ZM33 18C32.2043 18 31.4413 17.6839 30.8787 17.1213C30.3161 16.5587 30 15.7956 30 15V10.23L37.77 18H33ZM54 30H39C38.2043 30 37.4413 30.3161 36.8787 30.8787C36.3161 31.4413 36 32.2043 36 33V57C36.0014 57.5427 36.1501 58.0749 36.4301 58.5398C36.7101 59.0047 37.111 59.3849 37.59 59.64C38.0591 59.8809 38.5834 59.9938 39.1101 59.9675C39.6368 59.9412 40.1473 59.7765 40.59 59.49L46.5 55.59L52.5 59.49C52.9482 59.7492 53.4558 59.888 53.9735 59.8929C54.4912 59.8978 55.0014 59.7686 55.4544 59.518C55.9074 59.2673 56.2878 58.9037 56.5586 58.4624C56.8295 58.0212 56.9815 57.5174 57 57V33C57 32.2043 56.6839 31.4413 56.1213 30.8787C55.5587 30.3161 54.7957 30 54 30ZM51 51.36L48.18 49.47C47.6839 49.1347 47.0988 48.9555 46.5 48.9555C45.9012 48.9555 45.3161 49.1347 44.82 49.47L42 51.36V36H51V51.36Z"
        })
    }) : props.name == "lux" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg ",
        className: props.css,
        viewBox: "0 0 44 63",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M36.0006 5.2152C33.4712 3.04923 30.5092 1.49851 27.3309 0.67616C24.1525 -0.146186 20.8379 -0.219405 17.6289 0.461846C13.3561 1.36047 9.43591 3.56033 6.3658 6.78232C3.29568 10.0043 1.214 14.1032 0.384874 18.559C-0.220602 21.8998 -0.110577 25.3387 0.7071 28.6302C1.52478 31.9217 3.02996 34.9848 5.1153 37.601C7.05062 39.8748 8.15992 42.7825 8.25059 45.8192V54.4096C8.25059 56.6879 9.11986 58.8729 10.6672 60.4839C12.2145 62.0949 14.3131 63 16.5013 63H27.5023C29.6906 63 31.7892 62.0949 33.3365 60.4839C34.8838 58.8729 35.7531 56.6879 35.7531 54.4096V46.3633C35.8454 43.0106 37.0284 39.79 39.1084 37.2288C42.7528 32.5349 44.4707 26.5332 43.8888 20.528C43.3069 14.5227 40.4721 8.99924 36.0006 5.15793V5.2152ZM30.2526 54.4096C30.2526 55.169 29.9628 55.8974 29.4471 56.4344C28.9313 56.9714 28.2318 57.2731 27.5023 57.2731H16.5013C15.7719 57.2731 15.0724 56.9714 14.5566 56.4344C14.0408 55.8974 13.7511 55.169 13.7511 54.4096V51.5461H30.2526V54.4096ZM34.8455 33.6781C32.0801 37.0931 30.4667 41.358 30.2526 45.8192H24.7521V37.2288C24.7521 36.4693 24.4623 35.741 23.9466 35.204C23.4308 34.667 22.7313 34.3653 22.0018 34.3653C21.2724 34.3653 20.5729 34.667 20.0571 35.204C19.5413 35.741 19.2516 36.4693 19.2516 37.2288V45.8192H13.7511C13.6785 41.4326 12.12 37.2138 9.35069 33.9072C7.52354 31.6278 6.29486 28.8944 5.78447 25.9735C5.27408 23.0525 5.49938 20.0437 6.43842 17.2404C7.37745 14.4371 8.99817 11.935 11.1425 9.97809C13.2869 8.02114 15.8817 6.67615 18.674 6.07424C21.0738 5.5598 23.5534 5.60819 25.933 6.2159C28.3125 6.8236 30.5322 7.97537 32.4309 9.58759C34.3296 11.1998 35.8597 13.232 36.9101 15.5366C37.9604 17.8413 38.5047 20.3605 38.5033 22.9114C38.5237 26.834 37.2302 30.6413 34.8455 33.6781Z"
        })
    }) : props.name == "aereo" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg ",
        className: props.css,
        viewBox: "0 0 66 38",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M65.9099 11.1828C66.097 10.423 65.9905 9.62154 65.6111 8.93561C64.6426 7.27284 63.3519 5.81566 61.813 4.64769C60.2741 3.47971 58.5172 2.62392 56.6432 2.12944C54.7692 1.63495 52.815 1.51149 50.8926 1.76615C48.9703 2.02081 47.1177 2.64857 45.4412 3.61342L39.0167 7.27981L24.0761 0.331398C23.6513 0.113651 23.1799 0 22.7015 0C22.2231 0 21.7518 0.113651 21.327 0.331398L12.3626 5.44661C11.9196 5.69948 11.5496 6.06063 11.288 6.4955C11.0264 6.93037 10.8819 7.4244 10.8685 7.9303C10.8541 8.43996 10.973 8.94466 11.2139 9.39539C11.4547 9.84612 11.8093 10.2276 12.2431 10.5027L22.1039 16.6528L16.9046 19.6096L2.6213 21.3245C2.04712 21.3948 1.50591 21.6285 1.06336 21.9972C0.620817 22.366 0.295977 22.8539 0.128279 23.4018C-0.039419 23.9498 -0.0427635 24.5341 0.118652 25.0838C0.280067 25.6336 0.5993 26.1251 1.03759 26.4988L11.6156 35.5466C13.0082 36.8617 14.7917 37.6983 16.7021 37.9326C18.6125 38.1669 20.5485 37.7865 22.2234 36.8475L64.4158 12.9864C64.7754 12.8017 65.0933 12.5465 65.3501 12.2365C65.607 11.9264 65.7974 11.5679 65.9099 11.1828ZM19.5042 31.8802C18.9302 32.1927 18.2684 32.3099 17.6204 32.2137C16.9725 32.1175 16.3745 31.8133 15.9185 31.3479L10.241 26.5284L18.3986 25.5527C18.7995 25.5018 19.1858 25.3711 19.5341 25.1683L29.5742 19.4617C30.0215 19.2063 30.3943 18.8405 30.6561 18.4C30.918 17.9595 31.06 17.4594 31.0683 16.9485C31.0744 16.441 30.9484 15.9405 30.7025 15.4951C30.4565 15.0498 30.0988 14.6746 29.6639 14.4056L19.803 8.22598L23.09 6.36321L38.0306 13.2229C38.4554 13.4407 38.9268 13.5543 39.4052 13.5543C39.8835 13.5543 40.3549 13.4407 40.7797 13.2229L48.4293 8.8469C49.9969 7.97762 51.7923 7.59457 53.5827 7.74747C55.373 7.90037 57.0755 8.58216 58.4694 9.70436L19.5042 31.8802Z"
        })
    }) : "";
};


/***/ })

};
;