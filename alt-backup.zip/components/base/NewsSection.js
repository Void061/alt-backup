import TitleAndSubtitle from "./TitleAndSubtitle";
import NewsCard from "./NewsCard";
import Divider from "./Divider";
import StrapiClient from "../../lib/strapi-client";




export default NewsSection;